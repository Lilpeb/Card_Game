
import json
from balatro_stackCards import Card

SAVE_FILE = "balatro_save.json"

def save_game(deck, player):
    """Save the current deck and player's hand."""

    game_data = {
        "deck": [
            {"rank": card.rank, "suit": card.suit}
            for card in deck.cards
        ],

        "player_hand": [
            {"rank": card.rank, "suit": card.suit}
            for card in player.cards
        ]
    }

    with open(SAVE_FILE, "w", encoding="utf-8") as file:
        json.dump(game_data, file, indent=4)

    print("\nGame saved successfully!")

def load_game(deck, player):
    """Load a previously saved game."""

    try:
        with open(SAVE_FILE, "r", encoding="utf-8") as file:
            game_data = json.load(file)

        # Restore the remaining deck
        deck.cards = [
            Card(card["rank"], card["suit"])
            for card in game_data["deck"]
        ]

        # Restore the player's hand
        player.cards = [
            Card(card["rank"], card["suit"])
            for card in game_data["player_hand"]
        ]

        print("\nGame loaded successfully!")
        return True

    except FileNotFoundError:
        print("\nNo save file found. Starting a new game.")
        return False

    except (json.JSONDecodeError, KeyError, TypeError):
        print("\nSave file is damaged or invalid. Starting a new game.")
        return False